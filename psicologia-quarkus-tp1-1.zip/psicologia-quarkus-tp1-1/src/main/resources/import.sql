
INSERT INTO produto (descricao, marca, valor) VALUES ('ração de cachorro 1kg', 'El Copir', 32.90);
INSERT INTO produto (descricao, marca, valor) VALUES ('ração para filhotes, cachorros e gatos 3 kg', 'GATHRRGOS', 29.00);
